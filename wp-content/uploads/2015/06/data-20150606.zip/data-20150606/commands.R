#  CSVインポート
grades <- read.csv("seiseki.csv", sep=",")
register <- read.csv("gakuseki.csv", sep=",")
pref <- read.csv("kenmei.csv", sep=",")
head(grades) # データフレームの一部、下は表示結果

# 列名の表示変更
names(pref)
names(pref)[c(1,2)] <- c("県番号","県名")
names(pref)

#  データフレームの確認
str(pref) # 属性の型
summary(pref) # 基本等計量

# データフレームの要素へのアクセス
pref$県名
pref$県名[22]
pref[[2]][22]

# データフレームのエクスポート
write.csv(pref, file="", na="", sep="\t")


# 例題 1. データフレームの結合
register_p <- merge(register, pref[,c(-3)], by.x="出身県番号", by.y="県番号")
head(register_p, 5)

# 例題 2. データフレームregister_pからクロス集計関数xtabsを用いて出身県別に学部ごとの学生数を集計し、結果を変数pref_deptに代入せよ。
(pref_dept <- xtabs( ~ 県名 + 学部名, data=register_p))

# as.data.frame関数
pref_dept_df <- as.data.frame(pref_dept)
head(pref_dept_df, 5)

# 例題 3.  学籍データregister_pから、学部ごとの平均通学時間を集計し、commute_aveに代入せよ
(commute_ave <- aggregate(通学時間 ~ 学部名,  register_p, mean))

# 例 : 学籍データregister_pから、学部と出身県ごとに通学時間の標準偏差を求めよ。
max_commute <- aggregate(通学時間 ~ 学部名 + 県名, register_p, max)
head(max_commute, 13)


# 例 : register_pから出身県と学部で通学時間の平均を集計せよ。
library(reshape2)

#
# 
m <- melt(register_p, id.vars=c("県名", "学部名"), measure.vars=c("通学時間"))
# 通学時間だけ抽出
head(m,3)
#
d <- dcast(m, 県名 ~ 学部名, mean)
head(d,3)


# 例題 4. 学籍データregister_pから通学時間の度数分布グラフ（ヒストグラム）を示せ。
hist(register_p$通学時間)

# 例題 5. 通学時間について、四分位数を箱ヒゲ図で示せ。
boxplot(register_p$通学時間)

# 例題 6. 学生の平均得点と通学時間の散布図を示せ。 
plot(comm_pnt$平均点, comm_pnt$通学時間, pch=16)
text(comm_pnt[343,2],comm_pnt[343,3], pos=1, comm_pnt[343,1])

